class PhotosController < ApplicationController
  before_action :authenticate_user!
  before_action :set_gallery
    def set_gallery
      @gallery = Gallery.find(params[:gallery_id])
    end
  before_action :set_photo, only: %i[ show edit update destroy ]
  before_action :authorize_user!

  # GET /photos or /photos.json
  def index
    @photos = Photo.all
  end
  
  # GET /photos/1 or /photos/1.json
  def show
  end

  # GET /photos/new
  def new
    @photo = Photo.new
  end

  # GET /photos/1/edit
  def edit
  end

  # POST /photos or /photos.json
  def create
    @photo = @gallery.photos.build(photo_params)
    if @photo.save
      redirect_to @gallery, notice: "Photo added successfully."
    else
      render :new
    end
  end

  # PATCH/PUT /photos/1 or /photos/1.json
  def update
    @photo = Photo.find(params[:id])

    if params[:cropped_image]
     @photo.image.attach(params[:cropped_image])
    end

    if @photo.save
     render json: { message: "Success" }, status: :ok
    else
      render json: { errors: @photo.errors.full_messages }, status: :unprocessable_entity
  end
end

  end

  # DELETE /photos/1 or /photos/1.json
  def destroy
    @photo.destroy!

    respond_to do |format|
      format.html { redirect_to photos_path, status: :see_other, notice: "Photo was successfully deleted." }
      format.json { head :no_content }
    end
  end
  
  def authorize_user!
    redirect_to root_path, alert: "Not Authorized!" unless @gallery.user == current_user
  end
  
  def set_photo
    @photo = @gallery.photos.find(params[:id])
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_photo
      @photo = Photo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def photo_params
      params.require(:photo).permit(:caption, :image)
    end
